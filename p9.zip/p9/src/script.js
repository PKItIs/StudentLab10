// Array to store tasks
var tasks = [];

// Function to add task to the list
function addTask() {
    // Retrieving task from input field
    var task = document.getElementById("task").value;

    // Adding task to the array
    tasks.push({ name: task, completed: false });

    // Displaying tasks
    displayTasks();

    // Clearing input field after adding task
    document.getElementById("task").value = "";
}

// Function to display tasks
function displayTasks() {
    // Clearing previous task list
    document.getElementById("taskList").innerHTML = "";

    // Looping through tasks array
    tasks.forEach(function(task, index) {
        // Creating list item element
        var listItem = document.createElement("li");

        // Adding task name to list item
        listItem.textContent = task.name;

        // If task is completed, add strikethrough style
        if (task.completed) {
            listItem.style.textDecoration = "line-through";
        }

        // Adding event listener to mark task as completed on click
        listItem.addEventListener("click", function() {
            tasks[index].completed = !tasks[index].completed;
            displayTasks();
        });

        // Appending list item to task list
        document.getElementById("taskList").appendChild(listItem);
    });
}
