// Function to suggest activity based on weather condition
function suggestActivity() {
    // Retrieving weather condition from input field
    var weatherCondition = document.getElementById("weatherCondition").value;

    // Checking weather condition and suggesting activity
    if (weatherCondition.toLowerCase() === "sunny") {
        document.getElementById("activity").textContent = "It's sunny! You can go for a picnic.";
    } else if (weatherCondition.toLowerCase() === "rainy") {
        document.getElementById("activity").textContent = "It's rainy! You can stay indoors and read a book.";
    } else if (weatherCondition.toLowerCase() === "snowy") {
        document.getElementById("activity").textContent = "It's snowy! You can build a snowman.";
    } else {
        document.getElementById("activity").textContent = "Weather condition not recognized. Please try again.";
    }
}
