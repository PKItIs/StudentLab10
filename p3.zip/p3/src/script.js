// Quiz questions and answers
var questions = [
    {
        question: "What is the capital of France?",
        options: {
            a: "Paris",
            b: "London",
            c: "Berlin",
            d: "Rome"
        },
        correctAnswer: "a"
    },
    {
        question: "Which planet is known as the Red Planet?",
        options: {
            a: "Mars",
            b: "Venus",
            c: "Jupiter",
            d: "Saturn"
        },
        correctAnswer: "a"
    }
];

// Function to display questions and options
function displayQuestion(index) {
    var questionObj = questions[index];
    document.getElementById("question").textContent = questionObj.question;
    document.getElementById("labelA").textContent = questionObj.options.a;
    document.getElementById("labelB").textContent = questionObj.options.b;
    document.getElementById("labelC").textContent = questionObj.options.c;
    document.getElementById("labelD").textContent = questionObj.options.d;
}

// Function to evaluate user's answer
function evaluateAnswer(index, userAnswer) {
    var correctAnswer = questions[index].correctAnswer;
    return userAnswer === correctAnswer;
}

// Adding event listener to form submission
document.getElementById("quizForm").addEventListener("submit", function(event) {
    // Preventing default form submission behavior
    event.preventDefault();
    // Retrieving user's answer
    var userAnswer = document.querySelector('input[name="answer"]:checked').value;
    // Evaluating user's answer
    var isCorrect = evaluateAnswer(currentQuestionIndex, userAnswer);
    // Displaying result
    document.getElementById("result").textContent = isCorrect ? "Correct!" : "Incorrect!";
    // Displaying next question
    displayQuestion(++currentQuestionIndex);
});

// Displaying the first question when the page loads
var currentQuestionIndex = 0;
displayQuestion(currentQuestionIndex);
