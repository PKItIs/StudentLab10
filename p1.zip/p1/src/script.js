// Function to change background color to a random color
function getRandomColor() {
    // List of hexadecimal characters
    var letters = '0123456789ABCDEF';
    var color = '#';
    // Generating a random color code
    for (var i = 0; i < 6; i++) {
        color += letters[Math.floor(Math.random() * 16)];
    }
    // Returning the random color code
    return color;
}

// Adding event listener to button
document.getElementById("changeColorBtn").addEventListener("click", function() {
    // Changing background color of body to a random color
    document.body.style.backgroundColor = getRandomColor();
});
