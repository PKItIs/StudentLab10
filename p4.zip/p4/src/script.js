// Function to update digital clock
function updateClock() {
    // Getting current date and time
    var now = new Date();
    var hours = now.getHours();
    var minutes = now.getMinutes();
    var seconds = now.getSeconds();

    // Formatting hours, minutes, and seconds
    hours = hours < 10 ? "0" + hours : hours;
    minutes = minutes < 10 ? "0" + minutes : minutes;
    seconds = seconds < 10 ? "0" + seconds : seconds;

    // Displaying digital clock
    document.getElementById("clock").textContent = hours + ":" + minutes + ":" + seconds;
}

// Calling updateClock function every second
setInterval(updateClock, 1000);

// Initial call to updateClock function to display time immediately
updateClock();
