// Function to process user command
function processCommand() {
    // Retrieving user command from input field
    var command = document.getElementById("command").value.toLowerCase();

    // Checking user command and displaying appropriate message
    switch (command) {
        case "look":
            document.getElementById("message").textContent = "You are in a dark room.";
            break;
        case "open door":
            document.getElementById("message").textContent = "The door is locked.";
            break;
        case "go north":
            document.getElementById("message").textContent = "You head north and find a treasure chest.";
            break;
        case "quit":
            document.getElementById("message").textContent = "Game over. Thanks for playing!";
            break;
        default:
            document.getElementById("message").textContent = "Command not recognized. Please try again.";
    }

    // Clearing input field after processing command
    document.getElementById("command").value = "";
}
