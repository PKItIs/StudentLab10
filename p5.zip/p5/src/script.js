// Function to validate form inputs
function validateForm(event) {
    // Preventing default form submission behavior
    event.preventDefault();

    // Retrieving form inputs
    var email = document.getElementById("email").value;
    var password = document.getElementById("password").value;

    // Validating email format
    var emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailPattern.test(email)) {
        document.getElementById("emailError").textContent = "Invalid email format";
    } else {
        document.getElementById("emailError").textContent = "";
    }

    // Validating password length
    if (password.length < 8) {
        document.getElementById("passwordError").textContent = "Password must be at least 8 characters long";
    } else {
        document.getElementById("passwordError").textContent = "";
    }
}

// Adding event listener to form submission
document.getElementById("validationForm").addEventListener("submit", validateForm);
