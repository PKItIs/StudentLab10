// Function to perform calculation based on operator
function calculate() {
    // Retrieving numerical inputs and operator
    var num1 = parseFloat(document.getElementById("num1").value);
    var operator = document.getElementById("operator").value;
    var num2 = parseFloat(document.getElementById("num2").value);

    var result;

    // Performing arithmetic operation based on selected operator
    switch (operator) {
        case "+":
            result = num1 + num2;
            break;
        case "-":
            result = num1 - num2;
            break;
        case "*":
            result = num1 * num2;
            break;
        case "/":
            result = num1 / num2;
            break;
        default:
            result = "Invalid operator";
    }

    // Displaying the result
    document.getElementById("result").textContent = "Result: " + result;
}

// Adding event listener to form submission
document.getElementById("calculatorForm").addEventListener("submit", function(event) {
    // Preventing default form submission behavior
    event.preventDefault();
    // Calling the calculate function to perform calculation
    calculate();
});
