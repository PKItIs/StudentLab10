// Function to start countdown timer
function startTimer() {
    // Retrieving duration from input field
    var duration = document.getElementById("duration").value;

    // Validating duration
    if (duration < 1 || isNaN(duration)) {
        alert("Please enter a valid duration (greater than 0 seconds).");
        return;
    }

    // Starting countdown timer
    var countdown = setInterval(function() {
        // Displaying current countdown value
        document.getElementById("countdown").textContent = "Time left: " + duration + " seconds";

        // Decrementing duration
        duration--;

        // Checking if countdown has reached zero
        if (duration < 0) {
            clearInterval(countdown); // Clearing interval to stop countdown
            document.getElementById("countdown").textContent = "Time's up!";
        }
    }, 1000); // Update countdown every second (1000 milliseconds)
}
