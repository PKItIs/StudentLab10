// Function to perform arithmetic operation
function calculate() {
    // Retrieving numbers and operation from input fields
    var num1 = parseFloat(document.getElementById("num1").value);
    var num2 = parseFloat(document.getElementById("num2").value);
    var operation = document.getElementById("operation").value;

    // Variable to store result
    var result;

    // Performing arithmetic operation based on selected operation
    switch (operation) {
        case "add":
            result = add(num1, num2);
            break;
        case "subtract":
            result = subtract(num1, num2);
            break;
        case "multiply":
            result = multiply(num1, num2);
            break;
        case "divide":
            result = divide(num1, num2);
            break;
        default:
            result = "Invalid operation";
    }

    // Displaying result
    document.getElementById("result").textContent = "Result: " + result;
}

// Function to add two numbers
function add(a, b) {
    return a + b;
}

// Function to subtract two numbers
function subtract(a, b) {
    return a - b;
}

// Function to multiply two numbers
function multiply(a, b) {
    return a * b;
}

// Function to divide two numbers
function divide(a, b) {
    // Checking for division by zero
    if (b === 0) {
        return "Cannot divide by zero";
    }
    return a / b;
}
